Install nodejs from: https://nodejs.org/en/download

Install mySql from: https://dev.mysql.com/downloads/installer/

Install SamWise source code

Run command MySQL terminal: CREATE DATABASE db;

Then run commands terminal at the source code's folder:

npm install -i

node index.js

To access the webpage: http://localhost:3000/