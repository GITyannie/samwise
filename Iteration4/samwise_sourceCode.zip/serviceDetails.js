// serviceDetails.js
document.addEventListener('DOMContentLoaded', function () {
    // Get the service UUID from the query parameter
    const urlParams = new URLSearchParams(window.location.search);
    const serviceUUID = urlParams.get('serviceUUID');

    // Fetch service details using AJAX or another method
    // Update the following code with the actual endpoint and data retrieval logic
    fetch(`/api/service/details?serviceUUID=${serviceUUID}`)
        .then(response => response.json())
        .then(data => {
            // Update HTML with service details
            document.getElementById('serviceName').innerText = data.service_name;
            document.getElementById('serviceType').innerText = data.service_type;
            document.getElementById('availableTimes').innerText = data.available_times;
            // Update more details as needed
        })
        .catch(error => console.error('Error fetching service details:', error));
});
