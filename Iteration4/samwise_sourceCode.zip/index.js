const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser'); 
const app = express();
const port = 3000;
app.use(express.json()); // Add this middleware to parse JSON in the request body

// Database configuration
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: 'db',
});


// Connect to MySQL
db.connect((err) => {
  if (err) {
    res.status(500).send('Error connecting to MySQL Server:',err);
  } else {
    console.log('Connected to MySQL database');
    createUsersTable();
    createServicesTable();
    createSchedulingTable();
  
  }
});

// Function to create the 'users' table
function createUsersTable() {
    const query = `
      CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL,
        email VARCHAR(100) NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;
  
    // Execute the query
    db.query(query, (err, results) => {
      if (err) {
        res.status(500).send('Error creating users table:', err);
      } else {
        console.log('Users table created successfully');
      }
    });
}
// Function to create the 'services' table
function createServicesTable() {
    const query = `
      CREATE TABLE IF NOT EXISTS services (
        id INT AUTO_INCREMENT PRIMARY KEY,
        service_uuid VARCHAR(36) NOT NULL,
        service_name VARCHAR(50) NOT NULL,
        service_type VARCHAR(50) NOT NULL,
        available_times VARCHAR(255) NOT NULL,
        provider_id INT,
        scheduled BOOLEAN DEFAULT false,  
        approved BOOLEAN DEFAULT false,
        FOREIGN KEY (provider_id) REFERENCES users(id) ON DELETE CASCADE,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;

    // Execute the query
    db.query(query, (err, results) => {
        if (err) {
            res.status(500).send('Error creating services table:', err);
        } else {
            console.log('Services table created successfully');
        }
    });
}
function createSchedulingTable() {
  const query = `
    CREATE TABLE IF NOT EXISTS scheduling (
      id INT AUTO_INCREMENT PRIMARY KEY,
      service_uuid VARCHAR(36) NOT NULL,
      scheduled BOOLEAN DEFAULT false,
      approved BOOLEAN DEFAULT false,
      requestor_id INT,
      provider_id INT,
      FOREIGN KEY (requestor_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (provider_id) REFERENCES users(id) ON DELETE CASCADE,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
  `;

  // Execute the query
  db.query(query, (err, results) => {
    if (err) {
      res.status(500).send('Error creating scheduling table:', err);
    } else {
      console.log('Scheduling table created successfully');
    }
  });
}

app.use(bodyParser.urlencoded({ extended: true }));


app.post('/register', (req, res) => {
  const username = req.body.username;
  const email = req.body.email;
  const password = req.body.password;
  const confirmPassword = req.body.confirmPassword;
  console.log("password",password)
  console.log("confirmPassword",confirmPassword)
  if (password !== confirmPassword) {
      res.send('Passwords do not match');
      return false; 
  }

  const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';
  db.query(query, [username, email, password], (err, results) => {
    if (err) {
      console.error('Error inserting data into MySQL table:', err);
      res.status(500).send('Error inserting data into MySQL table:');
    } else {
      console.log('Data inserted successfully');
      res.redirect('/');
    }
  });
});

// Handle login submission
app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // Query the database for the user
  const query = 'SELECT id FROM users WHERE username = ? AND password = ?';
  db.query(query, [username, password], (err, results) => {
    if (err) {
      console.error('Error querying the database:', err);
      res.status(500).send('Error querying the database:');
    } else {
      if (results.length > 0) {
          const userId = results[0].id;
          res.redirect(`/service?userId=${encodeURIComponent(userId)}`);
      } else {
        res.send('Invalid username or password');
      }
    }
  });
});

  // ...

  app.post('/service/edit', (req, res) => {
    const editServiceName = req.body.editServiceName;
    const editServiceType = req.body.editServiceType;
    const editAvailableTimes = req.body.editAvailableTimes;
    const serviceUUID = req.body.serviceUUID;
 
    // Update data in the services table
    const query = 'UPDATE services SET service_name = ?, service_type = ?, available_times = ? WHERE service_uuid = ?';
    db.query(query, [editServiceName, editServiceType, editAvailableTimes, serviceUUID], (err, results) => {
        if (err) {
            console.error('Error updating service data in MySQL table:', err);
            res.status(500).send('Error updating service data in MySQL table:');
        } else {
            console.log('Service data updated successfully');
            res.send('<script>alert("Service updated successfully"); window.location="/service";</script>');
        }
    });
});

// Add this route to handle scheduling
app.post('/service/schedule', (req, res) => {
  const serviceId = req.body.serviceId;
  const  reqId   = req.body.userId ;/* requestor_id */
  const providerId = req.body.providerId;/* provider_id */
  console.log("reqId",reqId);
  console.log("providerId",providerId);
  // Add your logic here to handle scheduling, for example, updating the scheduling table
  const schedulingQuery = 'INSERT INTO scheduling (service_uuid, requestor_id, provider_id) VALUES (?, ?, ?)';
  db.query(schedulingQuery, [serviceId, reqId , providerId ], (err, schedulingResults) => {
    if (err) {
      console.error('Error scheduling service in MySQL table:', err);
      res.status(500).send('Error scheduling service in MySQL table:');
    } else {
      console.log('Service scheduled successfully');

      // Update the services table if needed
      const updateQuery = 'UPDATE services SET scheduled = true WHERE service_uuid = ?';
      db.query(updateQuery, [serviceId], (updateErr, updateResults) => {
        if (updateErr) {
          console.error('Error updating service status in MySQL table:', updateErr);
          res.status(500).send('Error updating service status in MySQL table:');
        } else {
          console.log('Service status updated successfully');
          res.status(200).send('Service scheduled successfully');
        }
      });
    }
  });
});

app.post('/service/approve', (req, res) => {
  const serviceId = req.body.serviceId;
  const approveQuery = 'UPDATE services SET approved = true WHERE service_uuid = ?';
  db.query(approveQuery, [serviceId], (updateErr, updateResults) => {
    if (updateErr) {
      console.error('Error updating service status in MySQL table:', updateErr);
      res.status(500).send('Error updating service status in MySQL table:');
    } else {
      console.log('Service status updated successfully');
      res.status(200).send('Service scheduled successfully');
    }
  });
});
app.post('/service/decline', (req, res) => {
  const serviceId = req.body.serviceId;
  const approveQuery = 'UPDATE services SET approved = false WHERE service_uuid = ?';
  db.query(approveQuery, [serviceId], (updateErr, updateResults) => {
    if (updateErr) {
      console.error('Error updating service status in MySQL table:', updateErr);
      res.status(500).send('Error updating service status in MySQL table:');
    } else {
      console.log('Service status updated successfully');
      res.status(200).send('Service scheduled successfully');
    }
  });
});



app.post('/search', (req, res) => {
  const searchQuery = req.body.searchQuery;
  //const userId = req.body.searchUserId;
  const userId = req.body.searchUserId;
  console.log("userId at search",req.body)
  res.redirect(`/service/details?serviceName=${searchQuery}&userId=${userId}`);
});

app.set('view engine', 'ejs'); // Replace 'ejs' with your chosen engine
app.get('/service/details', (req, res) => {
const serviceName = req.query.serviceName;

const searchPattern = `%${serviceName}%`;
const query = 'SELECT * FROM services WHERE service_name LIKE ? OR service_type LIKE ?';; // Query using the service name

db.query(query, [serviceName,searchPattern], (err, results) => {
  if (err) {
    console.error('Error fetching service details:', err);
    res.status(500).send('Error fetching service details: There is no service which is created');
  } else {
   // console.log(results);
    res.render('serviceDetails', { results: results , userId: req.query.userId });
  }
});
});

app.post('/service/create', (req, res) => {
  const serviceName = req.body.serviceName;
  const serviceType = req.body.serviceType;
  const availableTimes = req.body.availableTimes;
 // const userId = req.body.userId; // Extract userId from the request query parameters
  const userId = req.body.userId;
  // Generate a UUID for the service
  const serviceUUID = generateUUID();
  // Insert data into the services table, including the userId
  const query = 'INSERT INTO services (service_uuid, service_name, service_type, available_times, provider_id) VALUES (?, ?, ?, ?, ?)';
  db.query(query, [serviceUUID, serviceName, serviceType, availableTimes, userId], (err, results) => {
    if (err) {
      console.error('Error inserting service data into MySQL table:', err);
      res.status(500).send('Error inserting service data into MySQL table:');
    } else {
      const filePath = path.join(__dirname, 'createdService.html');
      fs.readFile(filePath, 'utf8', (readErr, data) => {
        if (readErr) {
          console.error('Error reading HTML file:', readErr);
          res.status(500).send('Error reading HTML file:');
        } else {
          // Replace the placeholder with the dynamic data
          const modifiedData = data.replace('<%= serviceUUID %>', serviceUUID);

          // Send the modified content as the response
          res.send(modifiedData);
        }
      });
    }
  });
});


app.post('/service/delete', (req, res) => {
    const serviceUUID = req.body.serviceUUID; // Assuming you have a way to identify the service (e.g., UUID)

    // Delete the service from the services table
    const query = 'DELETE FROM services WHERE service_uuid = ?';
    db.query(query, [serviceUUID], (err, results) => {
        if (err) {
            console.error('Error deleting service from MySQL table:', err);
            res.status(500).send('Error deleting service from MySQL table:');
        } else {
            console.log('Service deleted successfully');
            // Redirect or send a response as needed
            res.send('<script>alert("Service deleted successfully"); window.location="/service";</script>');
        }
    });
});


function generateUUID() {
    return require('uuid').v4();
}

  

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.sendFile('index.html', { root: __dirname });
});

app.get('/service', (req, res) => {
  res.sendFile(path.join(__dirname, 'manageServices.html'));
});

app.listen(port, () => {
  console.log(`Now listening on port ${port}`);
});
