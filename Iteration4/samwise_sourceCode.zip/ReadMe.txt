Install nodejs from: https://nodejs.org/en/download

Install mySql from: https://dev.mysql.com/downloads/installer/

Install SamWise source code

Create db database with: 

Run command MySQL Shell terminal: CREATE DATABASE db;
or 

Open MySQL Workbench click �Create a new schema in the connected server� with name db

Then run commands terminal at the source code's folder:

npm install -i

npm install mysql2

node index.js

To access the webpage: http://localhost:3000/
